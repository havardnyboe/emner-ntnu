package com.pu.fitshare.models.training;

public enum TrainingIntensity {
    low,
    medium,
    high
}
