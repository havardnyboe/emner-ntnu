package com.pu.fitshare.models.training;

public enum TrainingType {
	endurance,
	power,
	group,
	swimming,
	running,
    cycling
}
